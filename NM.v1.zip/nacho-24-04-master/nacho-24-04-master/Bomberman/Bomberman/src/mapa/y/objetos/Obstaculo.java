package mapa.y.objetos;

public class Obstaculo extends Entidad{
	private static int nroObstaculo = 0;
	private int idObstaculo;
	
	public Obstaculo(final int posIniX,final int posIniY) {
		super(posIniX,posIniY);
		idObstaculo = nroObstaculo;
		nroObstaculo++;
	}
	
	public void destruir() {
			esVisible = false;
			System.out.println("Obstaculo "+ idObstaculo +" Destruido");

	}
	
}
